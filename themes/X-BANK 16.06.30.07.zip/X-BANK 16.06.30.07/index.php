<?php get_header(); ?>

	<!-- BG -->
	<?php include("includes/00_bg.php"); ?>

	<!-- RECEIPT -->
	<?php include("includes/00_receipt.php");  ?>

<?php get_footer(); ?>