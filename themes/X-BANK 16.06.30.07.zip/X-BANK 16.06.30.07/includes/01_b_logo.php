<ul id="r_menu">
	<span>
		<li><a class="menu_index" href="#index" id="index_fashion">Fashion</a></li>
		<li><a class="menu_index" href="#index" id="index_art">Art</a></li>
		<li><a class="menu_index" href="#index" id="index_design">Design</a></li>
	</span>
	<span>
		<li><a class="" href="#agenda">Agenda</a></li>
		<li><a class="" href="#about">About</a></li>
		<li><a class="" href="#vault">The Vault</a></li>
		<li><a class="" href="#contact">Contact</a></li>
	</span>
</ul>