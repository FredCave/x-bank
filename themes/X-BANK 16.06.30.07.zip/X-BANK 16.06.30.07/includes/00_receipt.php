<div id="receipt_wrapper">

	<div id="receipt">

		<?php include("01___logo.php"); ?>

		<?php include("02___vitrine.php"); ?>		
	
		<?php include("03___agenda.php"); ?>

		<?php include("04___index.php"); ?>	

		<?php include("05___about.php"); ?>

		<?php include("06___contact.php"); ?>

	</div>

</div>