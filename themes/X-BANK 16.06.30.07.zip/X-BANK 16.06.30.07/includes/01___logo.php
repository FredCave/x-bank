<section id="r_logo">
	
	<div class="section_content">

		<!-- RANDOM LOGO -->
		<?php include("01_a_logo.php"); ?>

		<!-- MENU -->
		<?php include("01_b_logo.php"); ?>		

	</div>

	<?php addBreak(); ?>

</section>