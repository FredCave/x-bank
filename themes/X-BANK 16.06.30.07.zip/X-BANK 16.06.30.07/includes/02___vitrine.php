<section id="r_vitrine">

	<div class="section_content">

		<h1><a href="" id="toggle-main" class="main_vitrine highlight">Collection</a></h1>

	</div>

</section>

<div class="r_hole">
	<div class="r_hole_l"></div>
	<div class="r_hole_inset"></div>
	<div class="r_hole_r"></div>
</div>

<section id="r_vitrine_bis">

	<div class="section_content">


	</div>

	<?php /*addBreak();*/ ?>

</section>